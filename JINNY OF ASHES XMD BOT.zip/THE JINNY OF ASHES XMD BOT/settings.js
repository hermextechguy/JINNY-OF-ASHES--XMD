const settings = {
  packname: 'ASH JINY',
  author: '‎',
  botName: "JINNY OF ASHES XMD",
  botOwner: 'hermex', // Your name
  ownerNumber: '263717263862', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.9",
};

module.exports = settings;
